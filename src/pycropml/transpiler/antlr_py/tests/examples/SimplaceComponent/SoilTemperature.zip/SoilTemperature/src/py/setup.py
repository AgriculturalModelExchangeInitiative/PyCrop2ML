import setuptools
setuptools.setup(name='SoilTemperature',
version='0.1',
description='',
url='#',
author='Gunther Krauss',
install_requires=['opencv-python'],
author_email='',
packages=setuptools.find_packages(),
zip_safe=False)