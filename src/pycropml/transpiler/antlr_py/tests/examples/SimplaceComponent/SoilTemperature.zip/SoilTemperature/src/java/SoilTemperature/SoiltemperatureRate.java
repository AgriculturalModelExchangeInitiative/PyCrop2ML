import  java.io.*;
import  java.util.*;
import java.time.LocalDateTime;

public class SoiltemperatureRate
{
    
    public SoiltemperatureRate() { }
    
    public SoiltemperatureRate(SoiltemperatureRate toCopy, boolean copyAll) // copy constructor 
    {
        if (copyAll)
        {
        }
    }
}